import pandas as pd

from os import listdir
from os.path import isfile, join

import string
from itertools import chain

from nltk import word_tokenize
from nltk.corpus import wordnet
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer

ps = PorterStemmer()
lemmatizer = WordNetLemmatizer()
stop = stopwords.words('english')
punctuations = list(string.punctuation)
punctuation_table = dict((ord(char), ' ') for char in string.punctuation)

dir_path = "/dir/path/to/Dataset/258_Data_Annotated/"
all_files = [f for f in listdir(dir_path) if isfile(join(dir_path, f))]

caption_line_nos = ["2", "3", "4", "12"]
pseudo_line_nos = ["1", "2", "3", "4", "11", "12"]
caption_unclassified_line_nos = ["0", "2", "3", "4", "11", "12"]

complexity_words = ["algorithm", "pseudocode", "time", "space", "complexity", "efficiency", "performance", "run", "computational", "best", "worst", "case", "optimal"]
complexity_time = ["Constant", "Logarithmic", "Linear", "Linearithmic", "Sublinear", "Quadratic", "Cubic", "Exponential", "Polynomial", "Poly", "Parallel", "Factorial", "Approximation"]

frequent_terms_filePath = "/dir/path/to/Dataset/caption_frequent_terms.csv"
df_caption_ft = pd.read_csv(frequent_terms_filePath, sep=',', encoding='utf-16', low_memory=False)
df_caption_ft["stem"] = df_caption_ft.apply(lambda row: ps.stem(row['term']), axis=1)
df_caption_ft["lemma"] = df_caption_ft.apply(lambda row: lemmatizer.lemmatize(row['term'], 'v'), axis=1)
df_caption_ft_all = set.union(*[set(df_caption_ft["term"]), set(df_caption_ft["stem"]), set(df_caption_ft["lemma"])])

summary_columns = ['file_name', 'complexity_line_no', 'caption_line_start', 'caption_line_end', 'complexity_line_txt', 'complexity_ctx', 'caption_txt', 'caption_tokens_count', 'token_matched', 'ratio', 'r_c', 'complexity_word_matched', 'complexity_time_matched']
df_summary = pd.DataFrame(columns=summary_columns)

def read_txt_file(filePath):
    df = pd.read_csv(open(filePath,'rt', encoding="utf8"), sep='\n', header=None, low_memory=False, quoting=3, error_bad_lines=False)
    df_n = df[df[0].str.contains("|", case=True, flags=0, regex=False) & df[0].str.contains("[::-::]", case=True, flags=0, regex=False)]
    s_df = df_n[0].str.split("\[::\-::\]", expand=True)
    df1 = s_df[0].str.split("\|", expand=True)
    st_df = pd.concat([df1, s_df], axis=1, join_axes=[df1.index])
    st_df.columns = ['line', 'class', 'lc', 'txt']
    st_df['class'] = st_df['class'].replace('', '0', regex=True)
    st_df['class'] = st_df['class'].fillna('0')
    return st_df
	
def get_comp_lines_df(comp_lines, reguler_lines):
    reguler_lines_index = reguler_lines.reset_index().drop('index', axis=1)
    ctx = comp_lines.apply(lambda row: reguler_lines_index.loc[
                               reguler_lines_index.index[reguler_lines_index['line']==row['line']].tolist()[0]-5:
                               reguler_lines_index.index[reguler_lines_index['line']==row['line']].tolist()[0]+5
                           ]['txt'].str.cat(sep=' ').translate(punctuation_table).lower().replace('–', ' ').replace('-', ' ').strip(), axis=1)
    comp_lines_ctx = pd.concat([comp_lines, ctx], axis=1, join_axes=[comp_lines.index])
    comp_lines_ctx.columns = ['line', 'class', 'lc', 'txt', 'ctx']
    comp_lines_ctx['tokens'] = comp_lines_ctx.apply(lambda row: [item for item in word_tokenize(row['ctx']) if item not in punctuations and item not in stop and not(len(item) == 1 and not str.isdigit(item)) ], axis=1)
    comp_lines_ctx['lemma'] = comp_lines_ctx.apply(lambda row: [lemmatizer.lemmatize(item, 'v') for item in row['tokens'] ], axis=1)
    comp_lines_ctx['stem'] = comp_lines_ctx.apply(lambda row: [ps.stem(item) for item in row['tokens'] ], axis=1)
    comp_lines_ctx['tokens_count'] = comp_lines_ctx['tokens'].str.len()
    return comp_lines_ctx
	
def get_caption_lines_df(st_df):
    caption_unclassified_lines = st_df.loc[st_df['class'].isin(caption_unclassified_line_nos)].reset_index().drop('index', axis=1)
    caption_lines = caption_unclassified_lines.loc[caption_unclassified_lines['class'].isin(caption_line_nos)]
    
    i = 0
    last_line = 0
    start_lines = []
    end_lines = []
    for index, row in caption_lines.iterrows():
        #print (index)
        if index - i > 1:
            end_lines.append(last_line)
            start_lines.append(row['line'])
        i = index
        last_line = row['line']
    end_lines.append(last_line)
    end_lines.pop(0)
    
    caption_lines_s_e = pd.DataFrame({'start_lines':start_lines, 'end_lines':end_lines})
    caption_lines_s_e['txt'] = caption_lines_s_e.apply(lambda row: caption_lines.loc[
            caption_lines.index[caption_lines['line']==row['start_lines']].tolist()[0]:
            caption_lines.index[caption_lines['line']==row['end_lines']].tolist()[0]
        ]['txt'].str.cat(sep=' ').translate(punctuation_table).lower().replace('–', ' ').replace('-', ' ').strip(), axis=1)
    if len([item for item in word_tokenize(caption_lines_s_e['txt'][0]) if item not in punctuations and item not in stop and not(len(item) == 1 and not str.isdigit(item))]) == 3 or len(caption_lines_s_e) == 1:
        caption_lines_s_e['tokens'] = None
    caption_lines_s_e['tokens'] = caption_lines_s_e.apply(lambda row:[item for item in word_tokenize(row['txt']) if item not in punctuations and item not in stop and not(len(item) == 1 and not str.isdigit(item)) ], axis=1)
    caption_lines_s_e['tokens_count'] = caption_lines_s_e['tokens'].str.len()
    return caption_lines_s_e
	
def update_summary(comp_lines_ctx, caption_lines_se_txt, file_name):
    global df_summary
    
    complexity_word_matched = set()
    complexity_time_matched = set()
    
    complexity_w = set(lemmatizer.lemmatize(item.lower(), 'v') for item in complexity_words)
    complexity_t = set(lemmatizer.lemmatize(item.lower(), 'v') for item in complexity_time)
    
    complexity_w_l = len(complexity_w)
    complexity_t_l = len(complexity_t)
    
    for comp_index, comp_row in comp_lines_ctx.iterrows():
        for caption_index, caption_row in caption_lines_se_txt.iterrows():
            i = 0.0
            all_tokens = set.union(*[set(comp_row['tokens']), set(comp_row['stem']), set(comp_row['lemma'])])
            complexity_word_matched = complexity_w.intersection(all_tokens)
            complexity_time_matched = complexity_t.intersection(all_tokens)
            
            for t in caption_row['tokens']:
                t_set = set([t, ps.stem(t), lemmatizer.lemmatize(t, 'v')])
                if len(t_set.intersection(all_tokens)) > 0:
                    if len(t_set.intersection(df_caption_ft_all)) > 0:
                        i = i + 0.9
                    else:
                        i = i + 1.0
                else:
                    is_synonym = False
                    synonyms = set(chain.from_iterable([word.lemma_names() for word in wordnet.synsets(t)]))
                    if len(synonyms.intersection(all_tokens)) > 0:
                        if len(t_set.intersection(df_caption_ft_all)) > 0:
                            i = i + 0.7
                        else:
                            i = i + 0.8
            
            r = round(i / caption_row['tokens_count'], 2)
            c1 = len(complexity_word_matched) / 5.0 / complexity_w_l
            c2 = len(complexity_time_matched) / 5.0 / complexity_t_l
            c = round(c1 + c2, 2)
            r_c = round(r + c, 2)
            
            #if (r >= 0.01):
            #if (r_c > 0.55):
            if (r >= 0.5) and (r_c > 0.55):
                l = [file_name,
                     pd.to_numeric(comp_row['line']),
                     caption_row['start_lines'],
                     caption_row['end_lines'],
                     comp_row['txt'],
                     comp_row['ctx'],
                     caption_row['txt'],
                     caption_row['tokens_count'],
                     round(i, 2),
                     r,
                     r_c,
                     complexity_word_matched,
                     complexity_time_matched
                    ]
                df_summary = df_summary.append(pd.DataFrame(data=[l], columns = summary_columns), ignore_index=True)

for file in all_files:
    filePath = dir_path + file
    st_df = read_txt_file(filePath)
    
    if len(st_df.loc[st_df['class'].isin(caption_line_nos)]) > 0:
        caption_lines_se_txt_f = get_caption_lines_df(st_df)
        
        if len(caption_lines_se_txt_f) > 0:
            reguler_lines = st_df.loc[~st_df['class'].isin(pseudo_line_nos)]
            complexity_lines = reguler_lines[reguler_lines['txt'].str
                                             .contains(r'\b\d*[OΩΘω0]\(.*[nmk\d(log)(ln)].*\)', case=False)]
            #complexity_lines = reguler_lines[reguler_lines['txt'].str
            #                                 .contains(r'\b\d*[OΩΘ0]\s*\(.*[nmk\d(log)(ln)].*\)', case=False)]

            if len(complexity_lines) > 0:
                comp_lines_ctx_f = get_comp_lines_df(complexity_lines, reguler_lines)
                update_summary(comp_lines_ctx_f, caption_lines_se_txt_f, file)
				
df_summary.to_csv("/dir/path/to/Dataset/summary_file.csv", sep=',', encoding='utf-16')